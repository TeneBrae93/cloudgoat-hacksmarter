

variable "region" {
  description = "The AWS region to deploy resources to."
  default     = "us-east-1"
  type        = string
}

variable "cgid" {
  description = "CGID variable for unique naming."
  type        = string
  default     = "lab"
}

variable "cg_whitelist" {
  description = "User's public IP address(es)"
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "stack-name" {
  description = "Name of the stack."
  default     = "CloudGoat"
  type        = string
}

variable "scenario-name" {
  description = "Name of the scenario."
  default     = "Glue_Privesc"
  type        = string
}

variable "ssh_public_key" {
  description = "SSH Public Key"
  default     = "cloudgoat.pub"
  type        = string
}

variable "ssh_private_key" {
  description = "SSH Private Key"
  default     = "cloudgoat"
  type        = string
}

variable "rds_database_name" {
  description = "db_name"
  default     = "bob12cgvdb"
  type        = string
}

variable "rds_username" {
  description = "rds_db_username"
  default     = "postgres"
  type        = string
}

variable "rds_password" {
  description = "rds_db_passwrod"
  default     = "bob12cgv"
  type        = string
}
