## This configures the minimum required Terraform and provider versions.
## Configure the AWS profile and region specified in the variables as well as default tags.

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
  default_tags {
    tags = {
      Name     = "cg-${var.cgid}"
      Stack    = var.stack-name
      Scenario = var.scenario-name
    }
  }
}

